'use client';

import Image from 'next/image';
import { useState, useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { motion, AnimatePresence } from 'motion/react';
import { QrCode, CheckCircle2, RefreshCw, XCircle, Smartphone, Loader2, Bold, Italic, Strikethrough } from 'lucide-react';

export default function Home() {
  const [qr, setQr] = useState<string | null>(null);
  const [status, setStatus] = useState<'idle' | 'scanning' | 'connected' | 'reconnecting' | 'disconnected' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);
  const [userId, setUserId] = useState('usuario123'); // Default for demo
  const [recipient, setRecipient] = useState('');
  const [messageText, setMessageText] = useState('');
  const [manualButtons, setManualButtons] = useState<string[]>([]);
  const [manualButtonText, setManualButtonText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [messages, setMessages] = useState<any[]>([]);
  const [quotedMessage, setQuotedMessage] = useState<any | null>(null);
  const [activeTab, setActiveTab] = useState<'chat' | 'automation'>('chat');
  const [automationEnabled, setAutomationEnabled] = useState(false);
  const [automationRules, setAutomationRules] = useState<{ keyword: string, reply: string, buttons?: string[] }[]>([]);
  const [newKeyword, setNewKeyword] = useState('');
  const [newReply, setNewReply] = useState('');
  const [newButtons, setNewButtons] = useState<string[]>([]);
  const [currentButtonText, setCurrentButtonText] = useState('');
  const socketRef = useRef<Socket | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    // Connect to the same origin
    const socket = io();
    socketRef.current = socket;

    socket.on('qr', (qrData: string) => {
      setQr(qrData);
      setStatus('scanning');
    });

    socket.on('connected', () => {
      setStatus('connected');
      setQr(null);
      socket.emit('get-automation', userId);
    });

    socket.on('reconnecting', () => {
      setStatus('reconnecting');
    });

    socket.on('disconnected', () => {
      setStatus('disconnected');
      setQr(null);
    });

    socket.on('session-reset', () => {
      setStatus('idle');
      setQr(null);
      alert('Sessão reiniciada com sucesso. Você pode tentar conectar novamente.');
    });

    socket.on('error-message', (msg: string) => {
      setError(msg);
      setStatus('error');
    });

    socket.on('message-status', (data: { success: boolean, error?: string, to?: string, code?: string }) => {
      setIsSending(false);
      if (data.success) {
        // Success feedback
        setMessageText('');
        setQuotedMessage(null);
        // We could add a temporary success toast here
      } else {
        // More descriptive error handling
        console.error(`Erro na Mensagem [${data.code}]:`, data.error);
        alert(`Falha ao enviar mensagem: ${data.error}`);
      }
    });

    socket.on('new-message', (msg: any) => {
      setMessages(prev => [msg, ...prev].slice(0, 50)); // Keep last 50
    });

    socket.on('automation-data', (data: { enabled: boolean, rules: { keyword: string, reply: string, buttons?: string[] }[] }) => {
      setAutomationEnabled(data.enabled);
      setAutomationRules(data.rules);
    });

    return () => {
      socket.disconnect();
    };
  }, [userId]);

  const handleConnect = () => {
    if (socketRef.current) {
      setError(null);
      setStatus('scanning');
      socketRef.current.emit('start-session', userId);
      socketRef.current.emit('get-automation', userId);
    }
  };

  const handleUpdateAutomation = (enabled: boolean, rules: { keyword: string, reply: string, buttons?: string[] }[]) => {
    if (socketRef.current) {
      socketRef.current.emit('update-automation', { userId, enabled, rules });
    }
  };

  const addAutomationRule = () => {
    if (!newKeyword || !newReply) return;
    const updatedRules = [...automationRules, { 
      keyword: newKeyword, 
      reply: newReply, 
      buttons: newButtons.length > 0 ? newButtons : undefined 
    }];
    setAutomationRules(updatedRules);
    handleUpdateAutomation(automationEnabled, updatedRules);
    setNewKeyword('');
    setNewReply('');
    setNewButtons([]);
    setCurrentButtonText('');
  };

  const addButtonToRule = () => {
    if (!currentButtonText || newButtons.length >= 3) return;
    setNewButtons([...newButtons, currentButtonText]);
    setCurrentButtonText('');
  };

  const removeButtonFromRule = (index: number) => {
    setNewButtons(newButtons.filter((_, i) => i !== index));
  };

  const removeAutomationRule = (index: number) => {
    const updatedRules = automationRules.filter((_, i) => i !== index);
    setAutomationRules(updatedRules);
    handleUpdateAutomation(automationEnabled, updatedRules);
  };

  const addManualButton = () => {
    if (!manualButtonText || manualButtons.length >= 3) return;
    setManualButtons([...manualButtons, manualButtonText]);
    setManualButtonText('');
  };

  const removeManualButton = (index: number) => {
    setManualButtons(manualButtons.filter((_, i) => i !== index));
  };

  const toggleAutomation = () => {
    const newState = !automationEnabled;
    setAutomationEnabled(newState);
    handleUpdateAutomation(newState, automationRules);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipient || !messageText) {
      alert('Por favor, insira o destinatário e a mensagem.');
      return;
    }
    if (socketRef.current && status === 'connected') {
      setIsSending(true);
      socketRef.current.emit('send-message', { 
        userId, 
        to: recipient, 
        text: messageText,
        buttons: manualButtons.length > 0 ? manualButtons : undefined,
        quoted: quotedMessage?.raw 
      });
      setManualButtons([]);
      setManualButtonText('');
    }
  };

  const applyFormat = (symbol: string) => {
    if (!textareaRef.current) return;

    const start = textareaRef.current.selectionStart;
    const end = textareaRef.current.selectionEnd;
    const text = textareaRef.current.value;
    const selectedText = text.substring(start, end);
    
    const formattedText = `${text.substring(0, start)}${symbol}${selectedText}${symbol}${text.substring(end)}`;
    
    setMessageText(formattedText);
    
    // Set focus back to textarea and restore selection
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        const newPos = start + symbol.length + selectedText.length + symbol.length;
        textareaRef.current.setSelectionRange(newPos, newPos);
      }
    }, 0);
  };

  return (
    <main className="min-h-screen bg-[#F0F2F5] flex flex-col items-center justify-center p-4 font-sans">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
        {/* Header */}
        <div className="bg-[#00A884] p-6 text-white text-center">
          <motion.div 
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="flex justify-center mb-3"
          >
            <Smartphone className="w-12 h-12" />
          </motion.div>
          <h1 className="text-2xl font-bold tracking-tight">WhatsApp Connect</h1>
          <p className="text-white/80 text-sm mt-1">Vincule seu dispositivo para começar</p>
        </div>

        {/* Content */}
        <div className="p-8 flex flex-col items-center">
          {/* Status Badge */}
          <div className="mb-6 flex items-center gap-2 px-3 py-1 rounded-full bg-gray-100 border border-gray-200">
            <div className={`w-2 h-2 rounded-full animate-pulse ${
              status === 'connected' ? 'bg-green-500' : 
              status === 'scanning' ? 'bg-yellow-500' :
              status === 'reconnecting' ? 'bg-blue-500' :
              status === 'error' ? 'bg-red-500' : 'bg-gray-400'
            }`} />
            <span className="text-[10px] font-bold uppercase tracking-wider text-gray-600">
              {status === 'idle' ? 'Pronto para Conectar' : 
               status === 'scanning' ? 'Aguardando Scan' :
               status === 'connected' ? 'Conectado' :
               status === 'reconnecting' ? 'Reconectando' :
               status === 'error' ? 'Erro de Conexão' : 'Desconectado'}
            </span>
          </div>

          <AnimatePresence mode="wait">
            {status === 'idle' && (
              <motion.div 
                key="idle"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="text-center"
              >
                <div className="mb-6 p-4 bg-gray-50 rounded-xl border border-dashed border-gray-300">
                  <p className="text-gray-600 text-sm leading-relaxed mb-4">
                    Digite um nome para sua sessão e clique no botão abaixo para gerar um código QR e conectar sua conta do WhatsApp.
                  </p>
                  <div className="space-y-2">
                    <label className="block text-[10px] font-bold text-gray-400 uppercase ml-1">ID da Sessão (Ex: seu-nome)</label>
                    <input
                      type="text"
                      placeholder="usuario123"
                      value={userId}
                      onChange={(e) => setUserId(e.target.value.replace(/[^a-zA-Z0-9_-]/g, ''))}
                      className="w-full px-4 py-2 bg-white border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A884] focus:border-transparent outline-none transition-all text-sm"
                    />
                  </div>
                </div>
                <button
                  onClick={handleConnect}
                  className="w-full py-3 px-6 bg-[#00A884] hover:bg-[#008F70] text-white font-semibold rounded-lg transition-all shadow-md hover:shadow-lg active:scale-[0.98]"
                >
                  Conectar Dispositivo
                </button>
              </motion.div>
            )}

            {status === 'scanning' && (
              <motion.div 
                key="scanning"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="flex flex-col items-center"
              >
                <div className="relative p-4 bg-white rounded-xl shadow-inner border border-gray-200 mb-6">
                  {qr ? (
                    <Image 
                      src={qr} 
                      alt="QR Code" 
                      width={256} 
                      height={256} 
                      className="w-64 h-64"
                      unoptimized // Since it's a data URL generated on the fly
                    />
                  ) : (
                    <div className="w-64 h-64 flex items-center justify-center bg-gray-50">
                      <Loader2 className="w-10 h-10 text-[#00A884] animate-spin" />
                    </div>
                  )}
                  <motion.div 
                    animate={{ y: [0, 240, 0] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                    className="absolute left-4 right-4 h-0.5 bg-[#00A884] shadow-[0_0_8px_#00A884]"
                  />
                </div>
                <div className="flex items-center gap-2 text-[#00A884] font-medium">
                  <QrCode className="w-5 h-5" />
                  <span>Escaneie com seu celular</span>
                </div>
              </motion.div>
            )}

            {status === 'connected' && (
              <motion.div 
                key="connected"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="w-full"
              >
                {/* Tabs */}
                <div className="flex border-b border-gray-100 mb-6">
                  <button 
                    onClick={() => setActiveTab('chat')}
                    className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider transition-all ${activeTab === 'chat' ? 'text-[#00A884] border-b-2 border-[#00A884]' : 'text-gray-400 hover:text-gray-600'}`}
                  >
                    Conversa
                  </button>
                  <button 
                    onClick={() => setActiveTab('automation')}
                    className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider transition-all ${activeTab === 'automation' ? 'text-[#00A884] border-b-2 border-[#00A884]' : 'text-gray-400 hover:text-gray-600'}`}
                  >
                    Automação
                  </button>
                </div>

                {activeTab === 'chat' ? (
                  <>
                    <div className="text-center mb-6">
                      <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                        <CheckCircle2 className="w-10 h-10 text-green-600" />
                      </div>
                      <h2 className="text-xl font-bold text-gray-800">Conectado com Sucesso!</h2>
                      <p className="text-gray-500 text-sm">Seu WhatsApp está vinculado.</p>
                    </div>

                    <form onSubmit={handleSendMessage} className="space-y-4 bg-gray-50 p-4 rounded-xl border border-gray-200">
                      {quotedMessage && (
                        <div className="bg-gray-100 border-l-4 border-[#00A884] p-2 rounded-r-lg flex justify-between items-start mb-2">
                          <div className="text-xs">
                            <p className="font-bold text-[#00A884]">{quotedMessage.pushName || quotedMessage.from}</p>
                            <p className="text-gray-600 truncate max-w-[200px]">{quotedMessage.text}</p>
                          </div>
                          <button 
                            type="button"
                            onClick={() => setQuotedMessage(null)}
                            className="text-gray-400 hover:text-red-500"
                          >
                            <XCircle className="w-4 h-4" />
                          </button>
                        </div>
                      )}
                      <div>
                        <label className="block text-xs font-semibold text-gray-500 uppercase mb-1 ml-1">Número do Destinatário</label>
                        <input
                          type="text"
                          placeholder="ex: 5511999999999"
                          value={recipient}
                          onChange={(e) => setRecipient(e.target.value)}
                          className="w-full px-4 py-2 bg-white border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A884] focus:border-transparent outline-none transition-all text-sm"
                        />
                      </div>
                      <div>
                        <div className="flex items-center justify-between mb-1 ml-1">
                          <label className="block text-xs font-semibold text-gray-500 uppercase">Mensagem</label>
                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => applyFormat('*')}
                              className="p-1 hover:bg-gray-200 rounded transition-colors text-gray-600"
                              title="Negrito"
                            >
                              <Bold className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => applyFormat('_')}
                              className="p-1 hover:bg-gray-200 rounded transition-colors text-gray-600"
                              title="Itálico"
                            >
                              <Italic className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => applyFormat('~')}
                              className="p-1 hover:bg-gray-200 rounded transition-colors text-gray-600"
                              title="Riscado"
                            >
                              <Strikethrough className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                        <textarea
                          ref={textareaRef}
                          placeholder="Digite sua mensagem aqui..."
                          value={messageText}
                          onChange={(e) => setMessageText(e.target.value)}
                          rows={3}
                          className="w-full px-4 py-2 bg-white border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A884] focus:border-transparent outline-none transition-all text-sm resize-none"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="block text-[10px] font-bold text-gray-400 uppercase">Botões de Resposta (Máx 3)</label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            placeholder="Texto do botão (ex: 'Sim')"
                            value={manualButtonText}
                            onChange={(e) => setManualButtonText(e.target.value)}
                            className="flex-1 px-3 py-1.5 bg-white border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A884] outline-none text-xs"
                          />
                          <button
                            type="button"
                            onClick={addManualButton}
                            disabled={manualButtons.length >= 3 || !manualButtonText}
                            className="px-3 py-1.5 bg-gray-200 hover:bg-gray-300 disabled:opacity-50 rounded-lg text-xs font-bold transition-colors"
                          >
                            +
                          </button>
                        </div>
                        {manualButtons.length > 0 && (
                          <div className="flex flex-wrap gap-2 mt-2">
                            {manualButtons.map((btn, i) => (
                              <span key={i} className="flex items-center gap-1 px-2 py-1 bg-green-100 text-[#00A884] rounded text-[10px] font-bold">
                                {btn}
                                <button type="button" onClick={() => removeManualButton(i)} className="hover:text-red-500">
                                  <XCircle className="w-3 h-3" />
                                </button>
                              </span>
                            ))}
                          </div>
                        )}
                      </div>

                      <button
                        type="submit"
                        disabled={isSending}
                        className="w-full py-2.5 bg-[#00A884] hover:bg-[#008F70] disabled:bg-gray-400 text-white font-semibold rounded-lg transition-all shadow-sm flex items-center justify-center gap-2"
                      >
                        {isSending ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            <span>Enviando...</span>
                          </>
                        ) : (
                          <span>Enviar Mensagem</span>
                        )}
                      </button>
                    </form>

                    {/* Message History */}
                    <div className="mt-8">
                      <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Mensagens Recentes</h3>
                      <div className="space-y-3 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
                        {messages.length === 0 ? (
                          <p className="text-center text-gray-400 text-xs py-4">Nenhuma mensagem ainda</p>
                        ) : (
                          messages.map((msg) => (
                            <div 
                              key={msg.id} 
                              onClick={() => {
                                setQuotedMessage(msg);
                                setRecipient(msg.from.split('@')[0]);
                              }}
                              className={`p-3 rounded-lg cursor-pointer transition-all hover:shadow-md border ${
                                msg.fromMe ? 'bg-green-50 border-green-100 ml-8' : 'bg-white border-gray-100 mr-8'
                              }`}
                            >
                              <div className="flex justify-between items-start mb-1">
                                <span className="text-[10px] font-bold text-[#00A884] truncate max-w-[120px]">
                                  {msg.fromMe ? 'Você' : (msg.pushName || msg.from.split('@')[0])}
                                </span>
                                <span className="text-[9px] text-gray-400">
                                  {new Date(msg.timestamp * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                              </div>
                              <p className="text-xs text-gray-700 break-words">{msg.text || 'Mensagem não textual'}</p>
                              <div className="mt-1 text-[9px] text-gray-400 text-right italic">Clique para responder</div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl border border-gray-200">
                      <div>
                        <h3 className="text-sm font-bold text-gray-800">Sistema de Auto-Resposta</h3>
                        <p className="text-xs text-gray-500">Responda automaticamente a palavras-chave</p>
                      </div>
                      <button 
                        onClick={toggleAutomation}
                        className={`w-12 h-6 rounded-full transition-all relative ${automationEnabled ? 'bg-[#00A884]' : 'bg-gray-300'}`}
                      >
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${automationEnabled ? 'left-7' : 'left-1'}`} />
                      </button>
                    </div>

                    <div className="space-y-4">
                      <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Adicionar Nova Regra</h4>
                      <div className="space-y-3 bg-gray-50 p-4 rounded-xl border border-gray-200">
                        <input
                          type="text"
                          placeholder="Palavra-chave (ex: 'olá')"
                          value={newKeyword}
                          onChange={(e) => setNewKeyword(e.target.value)}
                          className="w-full px-4 py-2 bg-white border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A884] focus:border-transparent outline-none transition-all text-sm"
                        />
                        <textarea
                          placeholder="Texto da auto-resposta..."
                          value={newReply}
                          onChange={(e) => setNewReply(e.target.value)}
                          rows={2}
                          className="w-full px-4 py-2 bg-white border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A884] focus:border-transparent outline-none transition-all text-sm resize-none"
                        />
                        
                        <div className="space-y-2">
                          <label className="block text-[10px] font-bold text-gray-400 uppercase">Botões de Resposta (Máx 3)</label>
                          <div className="flex gap-2">
                            <input
                              type="text"
                              placeholder="Texto do botão (ex: 'Sim')"
                              value={currentButtonText}
                              onChange={(e) => setCurrentButtonText(e.target.value)}
                              className="flex-1 px-3 py-1.5 bg-white border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00A884] outline-none text-xs"
                            />
                            <button
                              onClick={addButtonToRule}
                              disabled={newButtons.length >= 3 || !currentButtonText}
                              className="px-3 py-1.5 bg-gray-200 hover:bg-gray-300 disabled:opacity-50 rounded-lg text-xs font-bold transition-colors"
                            >
                              +
                            </button>
                          </div>
                          {newButtons.length > 0 && (
                            <div className="flex flex-wrap gap-2 mt-2">
                              {newButtons.map((btn, i) => (
                                <span key={i} className="flex items-center gap-1 px-2 py-1 bg-green-100 text-[#00A884] rounded text-[10px] font-bold">
                                  {btn}
                                  <button onClick={() => removeButtonFromRule(i)} className="hover:text-red-500">
                                    <XCircle className="w-3 h-3" />
                                  </button>
                                </span>
                              ))}
                            </div>
                          )}
                        </div>

                        <button
                          onClick={addAutomationRule}
                          className="w-full py-2 bg-[#00A884] hover:bg-[#008F70] text-white font-semibold rounded-lg transition-all shadow-sm text-sm"
                        >
                          Adicionar Regra
                        </button>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Regras Ativas</h4>
                      <div className="space-y-2 max-h-48 overflow-y-auto pr-2 custom-scrollbar">
                        {automationRules.length === 0 ? (
                          <p className="text-center text-gray-400 text-xs py-4">Nenhuma regra definida</p>
                        ) : (
                          automationRules.map((rule, index) => (
                            <div key={index} className="p-3 bg-white border border-gray-100 rounded-lg flex justify-between items-start group">
                              <div className="text-xs">
                                <p className="font-bold text-[#00A884]">Palavra-chave: {rule.keyword}</p>
                                <p className="text-gray-600 mt-1">{rule.reply}</p>
                                {rule.buttons && rule.buttons.length > 0 && (
                                  <div className="flex flex-wrap gap-1 mt-2">
                                    {rule.buttons.map((btn, bi) => (
                                      <span key={bi} className="px-2 py-0.5 bg-gray-100 border border-gray-200 rounded text-[9px] text-gray-500">
                                        {btn}
                                      </span>
                                    ))}
                                  </div>
                                )}
                              </div>
                              <button 
                                onClick={() => removeAutomationRule(index)}
                                className="text-gray-300 hover:text-red-500 transition-colors"
                              >
                                <XCircle className="w-4 h-4" />
                              </button>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                )}

                <div className="text-center mt-6">
                  <button
                    onClick={() => socketRef.current?.emit('reset-session', userId)}
                    className="text-xs text-red-500 hover:text-red-600 underline"
                  >
                    Desconectar e Reiniciar Sessão
                  </button>
                </div>
              </motion.div>
            )}

            {status === 'reconnecting' && (
              <motion.div 
                key="reconnecting"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-8"
              >
                <RefreshCw className="w-12 h-12 text-blue-500 animate-spin mx-auto mb-4" />
                <h2 className="text-xl font-bold text-gray-800">Reconectando...</h2>
                <p className="text-gray-500 mt-2">Por favor, aguarde enquanto restauramos sua sessão.</p>
              </motion.div>
            )}

            {(status === 'error' || status === 'disconnected') && (
              <motion.div 
                key="error-disconnected"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-8"
              >
                <XCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
                <h2 className="text-xl font-bold text-gray-800">
                  {status === 'error' ? 'Erro de Conexão' : 'Desconectado'}
                </h2>
                <p className="text-gray-500 mt-2 text-sm">
                  {status === 'error' ? (error || 'Ocorreu um erro inesperado.') : 'A sessão foi fechada ou expirou.'}
                </p>
                <button
                  onClick={handleConnect}
                  className="mt-6 py-2 px-6 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors"
                >
                  Tentar Novamente
                </button>
                <button
                  onClick={() => socketRef.current?.emit('reset-session', userId)}
                  className="mt-4 text-xs text-red-500 hover:text-red-600 underline"
                >
                  Reiniciar Sessão e Limpar Dados
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer */}
        <div className="bg-gray-50 p-4 border-t border-gray-100">
          <div className="flex items-center justify-between px-4">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${status === 'connected' ? 'bg-green-500' : 'bg-gray-300'}`} />
              <span className="text-xs font-medium text-gray-500 uppercase tracking-wider">
                {status === 'connected' ? 'Online' : 'Offline'}
              </span>
            </div>
            <span className="text-[10px] text-gray-400 font-mono">ID: {userId}</span>
          </div>
        </div>
      </div>

      <p className="mt-8 text-gray-400 text-xs text-center max-w-xs leading-relaxed">
        Abra o WhatsApp no seu celular, toque em Menu ou Configurações e selecione Dispositivos Vinculados.
      </p>
    </main>
  );
}
