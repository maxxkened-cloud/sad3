import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import next from 'next';
import { parse } from 'url';
import makeWASocket, { 
  useMultiFileAuthState, 
  DisconnectReason, 
  WASocket,
  fetchLatestBaileysVersion
} from '@whiskeysockets/baileys';
import QRCode from 'qrcode';
import fs from 'fs';
import path from 'path';
import pino from 'pino';

const logger = pino({ level: 'debug' });

console.log('>>> Starting server.ts...');

const dev = process.env.NODE_ENV !== 'production';
const app = next({ dev });
const handle = app.getRequestHandler();

const expressApp = express();
const server = createServer(expressApp);
const io = new Server(server, {
  cors: { origin: '*' }
});

// Health check and basic route
expressApp.get('/api/health', (req, res) => {
  console.log(`[HEALTH CHECK] Ping received at ${new Date().toISOString()}`);
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

const sessions: { [key: string]: WASocket } = {};
const automationRulesPath = path.join(process.cwd(), 'automation_rules.json');

// Load automation rules
let automationRules: { [userId: string]: { enabled: boolean, rules: { keyword: string, reply: string, buttons?: string[] }[] } } = {};
if (fs.existsSync(automationRulesPath)) {
  try {
    automationRules = JSON.parse(fs.readFileSync(automationRulesPath, 'utf-8'));
  } catch (e) {
    console.error('Error loading automation rules', e);
  }
}

const saveAutomationRules = () => {
  fs.writeFileSync(automationRulesPath, JSON.stringify(automationRules, null, 2));
};

io.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`);

  // Automation events
  socket.on('get-automation', (userId: string) => {
    if (!automationRules[userId]) {
      automationRules[userId] = { enabled: false, rules: [] };
    }
    socket.emit('automation-data', automationRules[userId]);
  });

  socket.on('update-automation', ({ userId, enabled, rules }: { userId: string, enabled: boolean, rules: { keyword: string, reply: string, buttons?: string[] }[] }) => {
    automationRules[userId] = { enabled, rules };
    saveAutomationRules();
    socket.emit('automation-data', automationRules[userId]);
  });

  const startWhatsAppSession = async (userId: string, socket: any) => {
    console.log(`Starting session for user: ${userId}`);

    if (sessions[userId]) {
      console.log(`Closing existing session for ${userId}`);
      try {
        sessions[userId].end(undefined);
      } catch (e) {
        console.error('Error closing session', e);
      }
      delete sessions[userId];
    }

    const sessionsDir = path.join(process.cwd(), 'sessions');
    if (!fs.existsSync(sessionsDir)) {
      fs.mkdirSync(sessionsDir, { recursive: true });
    }
    const sessionPath = path.join(sessionsDir, userId);

    if (!fs.existsSync(sessionPath)) {
      fs.mkdirSync(sessionPath, { recursive: true });
    }

    try {
      // eslint-disable-next-line react-hooks/rules-of-hooks
      const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
      let version: any = [2, 2323, 4]; // Default fallback version
      try {
        const latest = await fetchLatestBaileysVersion();
        version = latest.version;
        console.log(`Using WA version v${version.join('.')}, isLatest: ${latest.isLatest}`);
      } catch (e) {
        console.error('Error fetching latest Baileys version, using fallback', e);
      }

      const sock = makeWASocket({
        auth: state,
        version,
        printQRInTerminal: false,
        logger: logger,
        browser: ['Ubuntu', 'Chrome', '110.0.5481.178'],
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
      });

      sessions[userId] = sock;

      sock.ev.on('connection.update', async (update) => {
        const { connection, qr, lastDisconnect } = update;

        if (qr) {
          try {
            const qrImage = await QRCode.toDataURL(qr);
            socket.emit('qr', qrImage);
          } catch (err) {
            console.error('Error generating QR code', err);
            socket.emit('error-message', 'Falha ao gerar o código QR. Por favor, tente novamente.');
          }
        }

        if (connection === 'open') {
          socket.emit('connected');
          console.log(`WhatsApp connected: ${userId}`);
        }

        if (connection === 'close') {
          const error = lastDisconnect?.error as any;
          const statusCode = error?.output?.statusCode || (lastDisconnect?.error as any)?.output?.payload?.statusCode;
          
          console.log(`WhatsApp connection closed: ${userId}, status: ${statusCode || 'unknown'}, error:`, error || 'none');
          
          const isConflict = statusCode === 401 || error?.message?.includes('conflict');
          const isRestartRequired = statusCode === DisconnectReason.restartRequired || statusCode === 515;
          const isLoggedOut = statusCode === DisconnectReason.loggedOut;

          if (isConflict) {
            console.log(`Connection conflict for ${userId}. Closing session.`);
            socket.emit('error-message', 'Conflito de conexão: Outra sessão está ativa. Por favor, reconecte.');
            socket.emit('disconnected');
            if (sessions[userId]) {
              try { sessions[userId].end(undefined); } catch(e) {}
              delete sessions[userId];
            }
            return;
          }

          if (isLoggedOut) {
            console.log(`WhatsApp logged out: ${userId}`);
            socket.emit('error-message', 'Desconectado do WhatsApp. Por favor, escaneie o código QR novamente.');
            socket.emit('disconnected');
            if (sessions[userId]) delete sessions[userId];
            return;
          }

          if (statusCode === 405) {
            console.log(`Connection failure 405 for ${userId}. Suggesting reset.`);
            socket.emit('error-message', 'Falha na conexão (405). Sua sessão pode ser inválida. Por favor, reinicie a sessão.');
          } else if (isRestartRequired) {
            console.log(`Restart required for ${userId}. Reconnecting...`);
          } else if (statusCode === DisconnectReason.timedOut) {
            console.log(`Connection timed out for ${userId}. Reconnecting...`);
          }

          // Reconnect for most errors except logout and conflict (handled above)
          console.log(`Attempting to reconnect: ${userId} in 3 seconds...`);
          socket.emit('reconnecting');
          
          setTimeout(() => {
            // Only reconnect if the session still exists in our map
            if (sessions[userId]) {
              startWhatsAppSession(userId, socket);
            }
          }, 3000);
        }
      });

      sock.ev.on('creds.update', saveCreds);

      sock.ev.on('messages.upsert', async (m) => {
        if (m.type === 'notify') {
          for (const msg of m.messages) {
            const remoteJid = msg.key.remoteJid;
            const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || '';
            const fromMe = msg.key.fromMe;

            console.log(`New message from ${remoteJid}:`, text);
            socket.emit('new-message', {
              id: msg.key.id,
              from: remoteJid,
              pushName: msg.pushName,
              text: text,
              timestamp: msg.messageTimestamp,
              fromMe: fromMe,
              raw: msg // Full message object for quoting
            });

            // Automation Logic
            if (!fromMe && remoteJid && automationRules[userId]?.enabled) {
              const userRules = automationRules[userId].rules;
              const normalizedText = text.toLowerCase().trim();
              
              for (const rule of userRules) {
                if (normalizedText.includes(rule.keyword.toLowerCase().trim())) {
                  console.log(`Automation triggered for ${remoteJid}: keyword "${rule.keyword}" -> reply "${rule.reply}"`);
                  try {
                    const messageContent: any = { 
                      text: rule.reply,
                      footer: 'Selecione uma opção abaixo:',
                    };
                    
                    if (rule.buttons && rule.buttons.length > 0) {
                      messageContent.templateButtons = rule.buttons.map((btnText, index) => ({
                        index: index + 1,
                        quickReplyButton: { 
                          displayText: btnText, 
                          id: `btn-${index}` 
                        }
                      }));
                    }

                    await sock.sendMessage(remoteJid, messageContent, { quoted: msg });
                  } catch (err) {
                    console.error('Error sending auto-reply:', err);
                  }
                  break; // Only one reply per message
                }
              }
            }
          }
        }
      });
    } catch (err: any) {
      console.error(`Failed to initialize session for ${userId}:`, err);
      socket.emit('error-message', `Falha ao iniciar sessão: ${err.message || 'Erro desconhecido'}`);
    }
  };

  socket.on('start-session', async (userId: string) => {
    await startWhatsAppSession(userId, socket);
  });

  socket.on('reset-session', async (userId: string) => {
    console.log(`Resetting session for user: ${userId}`);
    if (sessions[userId]) {
      try {
        sessions[userId].end(undefined);
      } catch (e) {
        console.error('Error closing session', e);
      }
      delete sessions[userId];
    }
    const sessionPath = path.join(process.cwd(), 'sessions', userId);
    if (fs.existsSync(sessionPath)) {
      fs.rmSync(sessionPath, { recursive: true, force: true });
    }
    socket.emit('session-reset');
  });

  socket.on('send-message', async ({ userId, to, text, buttons, quoted }: { userId: string, to: string, text: string, buttons?: string[], quoted?: any }) => {
    console.log(`Sending message from ${userId} to ${to}: ${text}, buttons: ${buttons?.length || 0}, quoted:`, quoted ? 'yes' : 'no');
    
    const sock = sessions[userId];
    if (!sock) {
      console.error(`No active session for user: ${userId}`);
      socket.emit('message-status', { 
        success: false, 
        error: 'Nenhuma sessão ativa. Por favor, conecte-se primeiro.',
        code: 'NO_SESSION'
      });
      return;
    }

    try {
      // Format number: remove non-digits
      let jid = to.replace(/\D/g, '');
      
      if (!jid) {
        socket.emit('message-status', { 
          success: false, 
          error: 'Número de destinatário inválido. Por favor, forneça um número de telefone válido.',
          code: 'INVALID_NUMBER'
        });
        return;
      }

      if (!jid.endsWith('@s.whatsapp.net')) {
        jid += '@s.whatsapp.net';
      }

      const options: any = {};
      if (quoted) {
        options.quoted = quoted;
      }

      const messageContent: any = { 
        text,
        footer: buttons && buttons.length > 0 ? 'Selecione uma opção abaixo:' : undefined,
      };
      
      if (buttons && buttons.length > 0) {
        messageContent.templateButtons = buttons.map((btnText, index) => ({
          index: index + 1,
          quickReplyButton: { 
            displayText: btnText, 
            id: `btn-${index}` 
          }
        }));
      }

      await sock.sendMessage(jid, messageContent, options);
      console.log(`Message sent successfully to ${jid}`);
      socket.emit('message-status', { success: true, to: jid });
    } catch (error: any) {
      console.error('Error sending message:', error);
      
      let errorMessage = 'Falha ao enviar mensagem.';
      let errorCode = 'SEND_ERROR';

      if (error.message?.includes('ENOTFOUND') || error.message?.includes('EAI_AGAIN')) {
        errorMessage = 'Erro de rede. Por favor, verifique sua conexão com a internet.';
        errorCode = 'NETWORK_ERROR';
      } else if (error.message?.includes('Connection closed')) {
        errorMessage = 'A conexão com o WhatsApp foi fechada. Tentando reconectar...';
        errorCode = 'CONNECTION_CLOSED';
      } else if (error.message?.includes('not found')) {
        errorMessage = 'Número de destinatário não encontrado no WhatsApp.';
        errorCode = 'NUMBER_NOT_FOUND';
      }

      socket.emit('message-status', { 
        success: false, 
        error: errorMessage,
        code: errorCode
      });
    }
  });
});

// Start Next.js preparation
console.log('>>> Preparing Next.js app...');
let isPrepared = false;
app.prepare().then(() => {
  isPrepared = true;
  console.log('>>> Next.js app prepared!');
}).catch(err => {
  console.error('>>> Next.js app preparation failed:', err);
});

// Handle all other routes with Next.js
expressApp.all(/.*/, (req, res) => {
  console.log(`>>> Request: ${req.method} ${req.url}`);
  if (!isPrepared) {
    console.log('>>> Next.js not prepared yet, sending 503');
    res.status(503).send('O servidor está iniciando, por favor atualize em alguns segundos...');
    return;
  }
  const parsedUrl = parse(req.url!, true);
  handle(req, res, parsedUrl);
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log('=========================================');
  console.log(`🚀 SERVER RUNNING ON PORT: ${PORT}`);
  console.log(`🌍 URL: http://localhost:${PORT}`);
  console.log(`📅 START TIME: ${new Date().toLocaleString()}`);
  console.log('=========================================');
  
  // Ensure sessions directory exists at startup
  const sessionsDir = path.join(process.cwd(), 'sessions');
  if (!fs.existsSync(sessionsDir)) {
    fs.mkdirSync(sessionsDir, { recursive: true });
    console.log('📁 Created sessions directory');
  }
});

